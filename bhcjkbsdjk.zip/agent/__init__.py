"""Advanced Terminal AI Agent package."""

__version__ = "1.0.0"
__all__ = ["__version__"]
