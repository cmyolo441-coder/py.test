"""The /goal command: run a goal fully autonomously at maximum capacity."""

from __future__ import annotations

from .base import Command, CommandContext, CommandResult


class GoalCommand(Command):
    name = "/goal"
    aliases = ("/goalmode", "/g")
    help = "Autonomously achieve a goal end-to-end at ultra effort (/goal <goal>)"

    def run(self, ctx: CommandContext) -> CommandResult:
        goal = ctx.args.strip()
        if not goal:
            ctx.ui.error("Usage: /goal <describe the goal to achieve>")
            return CommandResult()

        if ctx.app.agent is None and not ctx.app.build_agent():
            return CommandResult()

        from ..goal_mode import GoalMode

        run = GoalMode(ctx.app).run(goal)

        # Summary.
        rounds = sum(1 for s in run.steps if s.kind == "execute")
        if run.cancelled:
            ctx.ui.warn(f"Goal Mode stopped by user after {rounds} round(s).")
        elif run.complete:
            ctx.ui.success(
                f"\U0001f3af Goal achieved at '{run.effort}' effort "
                f"in {rounds} execution round(s)."
            )
        else:
            ctx.ui.warn(
                f"Goal not fully verified after {rounds} round(s). "
                "Re-run /goal to continue, or refine the goal."
            )

        # Refresh the status bar footer.
        ctx.ui.status_bar(
            ctx.config.provider,
            ctx.config.resolved_model(),
            ctx.app.conversation.token_estimate(),
        )
        return CommandResult()
